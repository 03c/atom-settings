#include <stdio.h>

int main()
{
    printf("Hello World from PlatformIO!\n");
    return 0;
}
