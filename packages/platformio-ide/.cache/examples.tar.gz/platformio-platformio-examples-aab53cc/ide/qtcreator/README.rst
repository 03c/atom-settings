Qt Creator IDE Integration
==========================

The detailed information and steps are described in the main documentation:
`PlatformIO integration with Qt Creator <http://docs.platformio.org/en/stable/ide/qtcreator.html>`_.

.. image:: http://docs.platformio.org/en/stable/_static/ide-platformio-qtcreator-7.png
    :target: http://docs.platformio.org/en/stable/ide/qtcreator.html
