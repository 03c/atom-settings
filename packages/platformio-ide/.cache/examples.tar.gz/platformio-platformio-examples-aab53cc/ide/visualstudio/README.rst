Visual Studio Integration
=========================

The detailed information and steps are described in the main documentation:
`PlatformIO integration with Visual Studio <http://docs.platformio.org/en/stable/ide/visualstudio.html>`_.

.. image:: http://docs.platformio.org/en/stable/_images/ide-vs-platformio-newproject-8.png
    :target: http://docs.platformio.org/en/stable/ide/visualstudio.html
