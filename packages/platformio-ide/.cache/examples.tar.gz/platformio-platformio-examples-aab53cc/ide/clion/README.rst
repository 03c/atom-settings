CLion IDE Integration
=====================

The detailed information and steps are described in the main documentation:
`PlatformIO integration with CLion IDE <http://docs.platformio.org/en/stable/ide/clion.html>`_.

.. image:: http://docs.platformio.org/en/stable/_images/ide-platformio-clion.png
    :target: http://docs.platformio.org/en/stable/ide/clion.html
