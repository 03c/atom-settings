Eclipse IDE Integration
=======================

The detailed information and steps are described in the main documentation:
`PlatformIO integration with Eclipse IDE <http://docs.platformio.org/en/stable/ide/eclipse.html>`_.

.. image:: http://docs.platformio.org/en/stable/_images/ide-platformio-eclipse.png
    :target: http://docs.platformio.org/en/stable/ide/eclipse.html
